package asw.model.types;

public enum SuggestionStatus {
	
	OPEN, CLOSED, ACCEPTED, PENDING
	
}
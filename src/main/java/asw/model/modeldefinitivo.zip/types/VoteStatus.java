package asw.model.types;

public enum VoteStatus {

	IN_FAVOUR, AGAINST
	
}
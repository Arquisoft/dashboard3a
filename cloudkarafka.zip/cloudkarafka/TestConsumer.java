//TestConsumer.java

import java.util.Arrays;
import java.util.Properties;
import java.lang.System;
import java.io.*;
import java.lang.Runtime;
import java.io.PrintWriter;

public class TestConsumer {
    public static void main(String[] args) {
        try {
            Properties props = new Properties();
            props.put("bootstrap.servers", getBrokers());
            props.put("group.id", "test");
            props.put("enable.auto.commit", "true");
            props.put("auto.commit.interval.ms", "1000");
            props.put("session.timeout.ms", "30000");
            props.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
            props.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
            props.put("security.protocol", "SSL");
            props.put("ssl.truststore.location", "truststore.jks");
            props.put("ssl.truststore.password", "test1234");
            props.put("ssl.keystore.location", "keystore.jks");
            props.put("ssl.keystore.password", "test1234");
            props.put("ssl.keypassword", "test1234");

	    //Establecemos las propiedades a Kafka
        } catch (FileNotFoundException e) {
            System.out.println(e);
        } catch (UnsupportedEncodingException e) {
            System.out.println(e);
        } catch (IOException e) {
            System.out.println(e);
        } catch (InterruptedException e) {
            System.out.println(e);
        }
    }

    private static String getBrokers() {
	return "steamer-01.srvs.cloudkafka.com:9093,steamer-03.srvs.cloudkafka.com:9093,steamer-02.srvs.cloudkafka.com:9093"
;
    }
}
